# Accounts
List of accounts that uses bot. this is nedded to save chatGPT history for chat properties.
